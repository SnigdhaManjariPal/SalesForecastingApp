﻿using Dapper.ORM;

namespace A2RSystemAPI.Context
{
    public class AppDbContext : DapperContext
    {
        public AppDbContext(IConfiguration configuration) : base(configuration.GetConnectionString("DapperDB"))
        {
        }
    }
}
