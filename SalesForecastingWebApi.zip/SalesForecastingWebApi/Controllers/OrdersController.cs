﻿using CoreApiResponse;
using Microsoft.AspNetCore.Mvc;
using SalesForecastingWebApi.Interface;
using SalesForecastingWebApi.Models;
using System.Globalization;
using System.Text;

namespace SalesForecastingWebApi.Controllers
{
    public class OrdersController : BaseController
    {
        private readonly IOrderRepository _orderRepository;

        public OrdersController(IOrderRepository orderRepository)
        {
            _orderRepository = orderRepository;
        }

        [HttpGet("totalsales/{year}")]
        public async Task<ActionResult<decimal>> GetTotalSalesByYear(int year)
        {
            var totalSales = await _orderRepository.GetTotalSalesByYear(year);
            return Ok(totalSales);
        }

        [HttpGet("salesbreakdown/{year}")]
        public async Task<ActionResult<List<(string State, decimal TotalSales)>>> GetSalesBreakdownByState(int year)
        {
            var salesBreakdown = await _orderRepository.GetSalesBreakdownByState(year);
            return Ok(salesBreakdown);
        }


        [HttpPost("applyincrement/{year}")]
        public async Task<ActionResult<decimal>> ApplyPercentageIncrement(int year, [FromBody] decimal percentage)
        {
            var newTotalSales = await _orderRepository.ApplyPercentageIncrement(year, percentage);
            return Ok(newTotalSales);
        }

        [HttpPost("applyincrementbystate/{year}")]
        public async Task<ActionResult<List<SalesBreakdown>>> ApplyPercentageIncrementByState(int year, [FromBody] Dictionary<string, decimal> statePercentageIncrements)
        {
            var salesBreakdown = await _orderRepository.ApplyPercentageIncrementByState(year, statePercentageIncrements);
            return Ok(salesBreakdown);
        }

        [HttpGet("downloadforecasteddata/{year}")]
        public async Task<IActionResult> DownloadForecastedData(int year, [FromQuery] decimal percentage)
        {
            var forecastedSalesData = await _orderRepository.GetForecastedSalesData(year, percentage);

            var csvString = new StringBuilder();
            csvString.AppendLine("State,PercentageIncrease,SalesValue");

            foreach (var item in forecastedSalesData)
            {
                csvString.AppendLine($"{item.State},{item.PercentageIncrease.ToString(CultureInfo.InvariantCulture)},{item.SalesValue.ToString(CultureInfo.InvariantCulture)}");
            }

            var byteArray = Encoding.UTF8.GetBytes(csvString.ToString());
            var stream = new MemoryStream(byteArray);

            return File(stream, "application/octet-stream", $"ForecastedSales_{year}.csv");
        }

        [HttpGet("salescomparison/{seedingYear}/{forecastedYear}")]
        public async Task<ActionResult<List<SalesComparison>>> GetSalesComparison(int seedingYear, int forecastedYear, [FromQuery] decimal percentage)
        {
            var salesComparison = await _orderRepository.GetSalesComparison(seedingYear, forecastedYear, percentage);
            return Ok(salesComparison);
        }

        [HttpGet("salesbreakdowncomparison/{seedingYear}/{forecastedYear}")]
        public async Task<ActionResult<List<SalesBreakdownComparison>>> GetSalesBreakdownComparisonByState(int seedingYear, int forecastedYear, [FromQuery] decimal percentage)
        {
            var salesBreakdownComparison = await _orderRepository.GetSalesBreakdownComparisonByState(seedingYear, forecastedYear, percentage);
            return Ok(salesBreakdownComparison);
        }
    }
}
