﻿namespace SalesForecastingWebApi.Models
{
    public class SalesBreakdownComparison
    {
        public string State { get; set; }
        public decimal SeedingYearSales { get; set; }
        public decimal ForecastedYearSales { get; set; }
    }
}
