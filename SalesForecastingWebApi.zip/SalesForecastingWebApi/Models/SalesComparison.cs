﻿namespace SalesForecastingWebApi.Models
{
    public class SalesComparison
    {
        public int Year { get; set; }
        public decimal TotalSales { get; set; }
    }
}
