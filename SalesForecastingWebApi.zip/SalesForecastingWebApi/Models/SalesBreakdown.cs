﻿namespace SalesForecastingWebApi.Models
{
    public class SalesBreakdown
    {
        public string State { get; set; }
        public decimal TotalSales { get; set; }
        public decimal IncrementedSales { get; set; }
    }
}
