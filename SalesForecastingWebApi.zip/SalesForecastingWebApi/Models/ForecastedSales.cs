﻿namespace SalesForecastingWebApi.Models
{
    public class ForecastedSales
    {
        public string State { get; set; }
        public decimal PercentageIncrease { get; set; }
        public decimal SalesValue { get; set; }
    }
}
