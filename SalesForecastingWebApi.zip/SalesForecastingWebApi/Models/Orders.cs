﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SalesForecastingWebApi.Models
{
    public class Orders
    {
        [Key]
        public string OrderId { get; set; }

        public DateTime OrderDate { get; set; }
        public DateTime ShipDate { get; set; }
        public string CustomerId { get; set; }
        public int SegmentId { get; set; }
        public string Country { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public int RegionId { get; set; }
        public int ShipModeId { get; set; }

    }
}
