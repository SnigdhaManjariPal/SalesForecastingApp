﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SalesForecastingWebApi.Models
{
    public class OrdersReturns
    {
        [Key]
        public string OrderId { get; set; }

        public string Comments { get; set; }
    }
}
