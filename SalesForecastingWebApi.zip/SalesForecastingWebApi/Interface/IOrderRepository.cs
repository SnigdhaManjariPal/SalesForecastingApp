﻿using SalesForecastingWebApi.Models;

namespace SalesForecastingWebApi.Interface
{
    public interface IOrderRepository
    {
        Task<decimal> GetTotalSalesByYear(int year);
        Task<List<SalesBreakdown>> GetSalesBreakdownByState(int year);
        Task<decimal> ApplyPercentageIncrement(int year, decimal percentage);
        Task<List<SalesBreakdown>> ApplyPercentageIncrementByState(int year, Dictionary<string, decimal> statePercentageIncrements);
        Task<List<ForecastedSales>> GetForecastedSalesData(int year, decimal percentage);
        Task<List<SalesComparison>> GetSalesComparison(int seedingYear, int forecastedYear, decimal percentage);
        Task<List<SalesBreakdownComparison>> GetSalesBreakdownComparisonByState(int seedingYear, int forecastedYear, decimal percentage);
    }
}
