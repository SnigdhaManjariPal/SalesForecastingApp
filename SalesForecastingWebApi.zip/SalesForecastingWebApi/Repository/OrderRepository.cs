﻿using A2RSystemAPI.Context;
using SalesForecastingWebApi.Interface;
using System.Data.SqlClient;
using System.Data;
using Dapper;
using SalesForecastingWebApi.Models;

namespace SalesForecastingWebApi.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly IDbConnection _dbConnection;

        public OrderRepository(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("DapperDB");
            _dbConnection = new SqlConnection(connectionString);
        }

        public async Task<decimal> GetTotalSalesByYear(int year)
        {
            string query = @"
            SELECT SUM(CASE 
                        WHEN r.OrderId IS NOT NULL THEN 0 
                        ELSE p.Sales 
                       END) AS TotalSales
            FROM Orders o
            INNER JOIN Products p ON o.OrderId = p.OrderId
            LEFT JOIN OrdersReturns r ON o.OrderId = r.OrderId
            WHERE YEAR(o.OrderDate) = @Year";

            var totalSales = await _dbConnection.QuerySingleAsync<decimal>(query, new { Year = year });
            return totalSales;
        }

        public async Task<List<SalesBreakdown>> GetSalesBreakdownByState(int year)
        {
            string query = @"
            SELECT o.State, SUM(CASE 
                                  WHEN r.OrderId IS NOT NULL THEN 0 
                                  ELSE p.Sales 
                                 END) AS TotalSales
            FROM Orders o
            INNER JOIN Products p ON o.OrderId = p.OrderId
            LEFT JOIN OrdersReturns r ON o.OrderId = r.OrderId
            WHERE YEAR(o.OrderDate) = @Year
            GROUP BY o.State";

            var salesBreakdown = await _dbConnection.QueryAsync<SalesBreakdown>(query, new { Year = year });
            return salesBreakdown.ToList();
        }

        public async Task<decimal> ApplyPercentageIncrement(int year, decimal percentage)
        {
            var totalSales = await GetTotalSalesByYear(year);
            var increment = totalSales * (percentage / 100);
            var newTotalSales = totalSales + increment;
            return newTotalSales;
        }

        public async Task<List<SalesBreakdown>> ApplyPercentageIncrementByState(int year, Dictionary<string, decimal> statePercentageIncrements)
        {
            var salesBreakdown = await GetSalesBreakdownByState(year);

            foreach (var breakdown in salesBreakdown)
            {
                if (statePercentageIncrements.TryGetValue(breakdown.State, out var percentage))
                {
                    var increment = breakdown.TotalSales * (percentage / 100);
                    breakdown.IncrementedSales = breakdown.TotalSales + increment;
                }
                else
                {
                    breakdown.IncrementedSales = breakdown.TotalSales; 
                }
            }

            return salesBreakdown;
        }

        public async Task<List<ForecastedSales>> GetForecastedSalesData(int year, decimal percentage)
        {
            var salesBreakdown = await GetSalesBreakdownByState(year);
            var forecastedSalesData = salesBreakdown.Select(s => new ForecastedSales
            {
                State = s.State,
                PercentageIncrease = percentage,
                SalesValue = s.TotalSales + (s.TotalSales * (percentage / 100))
            }).ToList();

            return forecastedSalesData;
        }

        public async Task<List<SalesComparison>> GetSalesComparison(int seedingYear, int forecastedYear, decimal percentage)
        {
            var seedingYearSales = await GetTotalSalesByYear(seedingYear);
            var forecastedSales = await ApplyPercentageIncrement(seedingYear, percentage);

            return new List<SalesComparison>
            {
                new SalesComparison
                {
                    Year = seedingYear,
                    TotalSales = seedingYearSales
                },
                new SalesComparison
                {
                    Year = forecastedYear,
                    TotalSales = forecastedSales
                }
            };
        }

        public async Task<List<SalesBreakdownComparison>> GetSalesBreakdownComparisonByState(int seedingYear, int forecastedYear, decimal percentage)
        {
            var seedingYearSalesBreakdown = await GetSalesBreakdownByState(seedingYear);

            // Calculate forecasted year sales breakdown based on seeding year sales and percentage increase
            var statePercentageIncrements = seedingYearSalesBreakdown.ToDictionary(s => s.State, s => percentage);
            var forecastedSalesBreakdown = await ApplyPercentageIncrementByState(seedingYear, statePercentageIncrements);

            var comparisonList = seedingYearSalesBreakdown.Select(s => new SalesBreakdownComparison
            {
                State = s.State,
                SeedingYearSales = s.TotalSales,
                ForecastedYearSales = forecastedSalesBreakdown.FirstOrDefault(f => f.State == s.State)?.IncrementedSales ?? 0
            }).ToList();

            return comparisonList;
        }

    }

}
